import os

# 关键修改：使用当前目录作为根目录
root_dir = "."

# 定义目录结构
dirs = [
    os.path.join(root_dir, "crud"),
    os.path.join(root_dir, "models"),
    os.path.join(root_dir, "routers"),
    os.path.join(root_dir, "schemas"),
    os.path.join(root_dir, "utils"),
    os.path.join(root_dir, "config"),
]

# 定义文件结构（包含所有必需的 __init__.py）
files = [
    os.path.join(root_dir, "crud", "news.py"),
    os.path.join(root_dir, "crud", "users.py"),
    os.path.join(root_dir, "crud", "__init__.py"),
    os.path.join(root_dir, "models", "news.py"),
    os.path.join(root_dir, "models", "users.py"),
    os.path.join(root_dir, "models", "__init__.py"),
    os.path.join(root_dir, "routers", "news.py"),
    os.path.join(root_dir, "routers", "users.py"),
    os.path.join(root_dir, "routers", "__init__.py"),
    os.path.join(root_dir, "schemas", "news.py"),
    os.path.join(root_dir, "schemas", "users.py"),
    os.path.join(root_dir, "schemas", "__init__.py"),
    os.path.join(root_dir, "utils", "__init__.py"),
    os.path.join(root_dir, "config", "db_conf.py"),
    os.path.join(root_dir, "config", "__init__.py"),
    os.path.join(root_dir, "__init__.py"),
]

# 创建目录（exist_ok=True 表示已存在则跳过，不会报错）
for dir_path in dirs:
    os.makedirs(dir_path, exist_ok=True)
    print(f"✅ 创建目录: {dir_path}")

# 创建文件（已存在则跳过，不会覆盖原有内容）
for file_path in files:
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            pass
        print(f"✅ 创建文件: {file_path}")
    else:
        print(f"ℹ️ 文件已存在，跳过: {file_path}")

print("\n🎉 项目结构创建完成！")