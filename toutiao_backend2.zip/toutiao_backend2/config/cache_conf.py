from typing import Any

import redis.asyncio as redis
import json


REDIS_HOST = "localhost"
REDIS_PORT = 6379
REDIS_DB = 0

# 创建 Redis 的连接对象
redis_client = redis.Redis(
    host=REDIS_HOST,  # Redis 服务器的主机地址
    port=REDIS_PORT,  # Redis 端口号
    db=REDIS_DB,  # Redis 数据库编号, 0~15
    decode_responses=True  # 是否将字节数据解码为字符串
)

#异步 Redis 缓存获取函数
async def get_cache(key: str):
    # return await redis_client.get(key)
    try:
        return await redis_client.get(key)
    except Exception as e:
        print(f"获取缓存失败: {e}")
        return None

#读取：列表和字典
async def get_json_cache(key: str):
    try:
        data = await redis_client.get(key)
        if data:
            return json.loads(data)  # 反序列化（原注释有误，loads是将字符串转为Python对象）
        return None
    except Exception as e:
        print(f"获取 JSON 缓存失败: {e}")
        return None

#设置缓存 setex(key,expire,value)
async def set_cache(key: str, value: Any, expire: int = 3600):
    try:
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False)
        await redis_client.setex(key, expire, value)
        return True
    except Exception as e:
        print(f"设置缓存失败: {e}")
        return False


async def del_cache(key: str):
    """删除指定缓存"""
    try:
        return await redis_client.delete(key)
    except Exception as e:
        print(f"删除缓存失败: {e}")
        return False


async def del_pattern_cache(pattern: str):
    """根据模式批量删除缓存（如 news:detail:*）"""
    try:
        keys = await redis_client.keys(pattern)
        if keys:
            return await redis_client.delete(*keys)
        return 0
    except Exception as e:
        print(f"批量删除缓存失败: {e}")
        return False