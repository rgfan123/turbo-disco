# 新闻相关的缓存方法
from typing import List, Dict, Any, Optional

from config.cache_conf import get_json_cache, set_cache, del_cache, del_pattern_cache

CATEGORIES_KEY = "news:categories"
NEWS_LIST_PREFIX = "news:list"
NEWS_DETAIL_PREFIX = "news:detail"


# ========== 分类缓存 ==========

async def get_cached_categories():
    return await get_json_cache(CATEGORIES_KEY)


# 分类数据稳定，缓存 2 小时
async def set_cache_categories(data: List[Dict[str, Any]], expire: int = 7200):
    return await set_cache(CATEGORIES_KEY, data, expire)


async def invalidate_categories_cache():
    """修改分类后清理分类缓存"""
    return await del_cache(CATEGORIES_KEY)


# ========== 新闻列表缓存 ==========

def _news_list_key(category_id: Optional[int], page: int, size: int) -> str:
    category_part = category_id if category_id is not None else "all"
    return f"{NEWS_LIST_PREFIX}:{category_part}:{page}:{size}"


async def get_cache_news_list(category_id: Optional[int], page: int, size: int):
    return await get_json_cache(_news_list_key(category_id, page, size))


# 列表缓存 30 分钟，加随机偏移防雪崩
async def set_cache_news_list(category_id: Optional[int], page: int, size: int, news_list: List[Dict[str, Any]], expire: int = 1800):
    import random
    jitter = random.randint(0, 120)
    return await set_cache(_news_list_key(category_id, page, size), news_list, expire + jitter)


async def invalidate_news_list_cache(category_id: Optional[int] = None):
    """新增/修改/删除新闻后清理列表缓存"""
    if category_id is not None:
        return await del_pattern_cache(f"{NEWS_LIST_PREFIX}:{category_id}:*")
    # 不指定分类时清理所有列表缓存
    return await del_pattern_cache(f"{NEWS_LIST_PREFIX}:*")


# ========== 新闻详情缓存 ==========

def _news_detail_key(news_id: int) -> str:
    return f"{NEWS_DETAIL_PREFIX}:{news_id}"


async def get_cache_news_detail(news_id: int):
    return await get_json_cache(_news_detail_key(news_id))


# 详情缓存 30 分钟
async def set_cache_news_detail(news_id: int, data: Dict[str, Any], expire: int = 1800):
    return await set_cache(_news_detail_key(news_id), data, expire)


async def invalidate_news_detail_cache(news_id: int):
    """修改或删除某条新闻后清理其详情缓存"""
    return await del_cache(_news_detail_key(news_id))


async def invalidate_all_news_cache():
    """批量清理所有新闻相关缓存（管理后台修改分类时使用）"""
    await del_cache(CATEGORIES_KEY)
    await del_pattern_cache(f"{NEWS_LIST_PREFIX}:*")
    await del_pattern_cache(f"{NEWS_DETAIL_PREFIX}:*")
