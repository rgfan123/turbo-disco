from typing import Dict, Any

from config.cache_conf import get_json_cache, set_cache, del_cache


def _user_info_key(user_id: int) -> str:
    return f"user:info:{user_id}"


async def get_cache_user_info(user_id: int):
    return await get_json_cache(_user_info_key(user_id))


# 用户信息缓存 10 分钟（用户可能频繁修改头像、简介等）
async def set_cache_user_info(user_id: int, data: Dict[str, Any], expire: int = 600):
    return await set_cache(_user_info_key(user_id), data, expire)


async def invalidate_user_info_cache(user_id: int):
    """用户修改资料/密码后清理缓存"""
    return await del_cache(_user_info_key(user_id))
