from fastapi.encoders import jsonable_encoder
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func

from cache.news_cache import (
    get_cached_categories, set_cache_categories, invalidate_categories_cache,
    get_cache_news_list, set_cache_news_list, invalidate_news_list_cache,
    get_cache_news_detail, set_cache_news_detail, invalidate_news_detail_cache,
    invalidate_all_news_cache,
)
from models.news import Category, News


async def get_categories(db: AsyncSession, skip: int = 0, limit: int = 100):
    cached_categories = await get_cached_categories()
    if cached_categories:
        return cached_categories

    stmt = select(Category).offset(skip).limit(limit)
    result = await db.execute(stmt)
    categories = result.scalars().all()

    if categories:
        categories = jsonable_encoder(categories)
        await set_cache_categories(categories)

    return categories


async def get_news_list(db: AsyncSession, category_id: int, skip: int = 0, limit: int = 10):
    page = skip // limit + 1
    cached_list = await get_cache_news_list(category_id, page, limit)

    if cached_list:
        return [News(**item) for item in cached_list]

    stmt = select(News).where(News.category_id == category_id).offset(skip).limit(limit)
    result = await db.execute(stmt)
    news_list = result.scalars().all()

    if news_list:
        from schemas.base import NewsItemBase
        news_data = [
            NewsItemBase.model_validate(item).model_dump(mode="json", by_alias=False)
            for item in news_list
        ]
        await set_cache_news_list(category_id, page, limit, news_data)

    return news_list


async def get_news_count(db: AsyncSession, category_id: int):
    stmt = select(func.count(News.id)).where(News.category_id == category_id)
    result = await db.execute(stmt)
    return result.scalar_one()


async def get_news_detail(db: AsyncSession, news_id: int):
    cached = await get_cache_news_detail(news_id)
    if cached:
        return News(**cached)

    stmt = select(News).where(News.id == news_id)
    result = await db.execute(stmt)
    news = result.scalar_one_or_none()

    if news:
        await set_cache_news_detail(news_id, jsonable_encoder(news))

    return news


async def increase_news_views(db: AsyncSession, news_id: int):
    stmt = update(News).where(News.id == news_id).values(views=News.views + 1)
    result = await db.execute(stmt)
    await db.commit()
    if result.rowcount > 0:
        await invalidate_news_detail_cache(news_id)
    return result.rowcount > 0


async def get_related_news(db: AsyncSession, news_id: int, category_id: int, limit: int = 5):
    stmt = (
        select(News)
        .where(News.category_id == category_id, News.id != news_id)
        .order_by(News.id.desc(), News.publish_time.desc())
        .limit(limit)
    )
    result = await db.execute(stmt)
    related_news = result.scalars().all()
    return [{
        "id": item.id,
        "title": item.title,
        "content": item.content,
        "image": item.image,
        "author": item.author,
        "publishTime": item.publish_time,
        "categoryId": item.category_id,
        "views": item.views,
    } for item in related_news]


# ========== 缓存清理接口（供路由层调用） ==========

async def invalidate_on_category_change():
    """分类增删改后调用：清理所有新闻缓存"""
    await invalidate_all_news_cache()


async def invalidate_on_news_change(news_id: int, category_id: int):
    """新闻增删改后调用：清理该新闻详情 + 所属分类列表缓存"""
    await invalidate_news_detail_cache(news_id)
    await invalidate_news_list_cache(category_id)
