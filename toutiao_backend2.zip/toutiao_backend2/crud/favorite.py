from sqlalchemy import select, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.favorite import Favorite
from models.news import News


async def is_news_favorite(
        db: AsyncSession,
        user_id: int,
        news_id: int
):
    query = select(Favorite).where(Favorite.user_id == user_id, Favorite.news_id == news_id)
    result = await db.execute(query)
    return result.scalar_one_or_none() is not None


async def add_favorite(db: AsyncSession, user_id: int, news_id: int):
    existing = await is_news_favorite(db, user_id, news_id)
    if existing:
        return False
    fav = Favorite(user_id=user_id, news_id=news_id)
    db.add(fav)
    await db.commit()
    return True


async def remove_favorite(db: AsyncSession, user_id: int, news_id: int):
    query = delete(Favorite).where(Favorite.user_id == user_id, Favorite.news_id == news_id)
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0


async def get_favorite_list(db: AsyncSession, user_id: int, page: int, page_size: int):
    offset = (page - 1) * page_size

    count_query = select(func.count(Favorite.id)).where(Favorite.user_id == user_id)
    total_result = await db.execute(count_query)
    total = total_result.scalar()

    query = (
        select(Favorite, News)
        .join(News, Favorite.news_id == News.id)
        .where(Favorite.user_id == user_id)
        .order_by(Favorite.created_at.desc())
        .offset(offset)
        .limit(page_size)
    )
    result = await db.execute(query)
    rows = result.all()

    items = []
    for fav, news in rows:
        items.append({
            "id": news.id,
            "title": news.title,
            "image": news.image,
            "author": news.author,
            "publishTime": news.publish_time.strftime("%Y-%m-%d %H:%M") if news.publish_time else "",
            "views": news.views,
            "favoriteTime": fav.created_at.strftime("%Y-%m-%d %H:%M") if fav.created_at else ""
        })

    return items, total


async def clear_favorites(db: AsyncSession, user_id: int):
    query = delete(Favorite).where(Favorite.user_id == user_id)
    await db.execute(query)
    await db.commit()
