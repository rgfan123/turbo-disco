from sqlalchemy import select, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.history import History
from models.news import News


async def add_history(db: AsyncSession, user_id: int, news_id: int):
    """添加浏览历史（若已存在则更新浏览时间）"""
    query = select(History).where(History.user_id == user_id, History.news_id == news_id)
    result = await db.execute(query)
    existing = result.scalar_one_or_none()

    if existing:
        from datetime import datetime
        existing.view_time = datetime.utcnow()
        await db.commit()
        return existing
    else:
        history = History(user_id=user_id, news_id=news_id)
        db.add(history)
        await db.commit()
        await db.refresh(history)
        return history


async def get_history_list(db: AsyncSession, user_id: int, page: int = 1, page_size: int = 10):
    """获取浏览历史列表（关联新闻信息）"""
    offset = (page - 1) * page_size

    count_query = select(func.count(History.id)).where(History.user_id == user_id)
    total_result = await db.execute(count_query)
    total = total_result.scalar()

    query = (
        select(History, News)
        .join(News, History.news_id == News.id)
        .where(History.user_id == user_id)
        .order_by(History.view_time.desc())
        .offset(offset)
        .limit(page_size)
    )
    result = await db.execute(query)
    rows = result.all()

    items = []
    for hist, news in rows:
        items.append({
            "id": news.id,
            "title": news.title,
            "image": news.image,
            "author": news.author,
            "publishTime": news.publish_time.strftime("%Y-%m-%d %H:%M") if news.publish_time else "",
            "views": news.views,
            "viewTime": hist.view_time.strftime("%Y-%m-%d %H:%M") if hist.view_time else ""
        })

    return items, total


async def delete_history(db: AsyncSession, user_id: int, history_id: int):
    """删除单条浏览历史"""
    query = delete(History).where(History.id == history_id, History.user_id == user_id)
    result = await db.execute(query)
    await db.commit()
    return result.rowcount > 0


async def clear_history(db: AsyncSession, user_id: int):
    """清空用户所有浏览历史"""
    query = delete(History).where(History.user_id == user_id)
    await db.execute(query)
    await db.commit()
