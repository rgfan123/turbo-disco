import datetime
import uuid
from idlelib import query

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy import select,update
from sqlalchemy.testing import exclude
from fastapi import HTTPException
from models.users import User, UserToken
from schemas.users import UserRequest
from utils import  security

async def get_user_by_username( db: AsyncSession,username: str):
    query = select(User).where(User.username == username)
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def create_user( db: AsyncSession,user_data:UserRequest):
    #先哈希加密——>add
    hashed_password =security.get_hash_password(user_data.password)
    user = User(username=user_data.username, password=hashed_password)
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user

#生成token
async def create_token( db: AsyncSession,user_id:int):

    token=uuid.uuid4()
    # expires_at= datetime.now() + datetime.timedelta(days=7)
    expires_at = datetime.datetime.now() + datetime.timedelta(days=7)
    query = select(UserToken).where(UserToken.user_id == user_id)
    result = await db.execute(query)
    user_token = result.scalar_one_or_none()

    if user_token:
        user_token.token = token
        user_token.expires_at = expires_at
    else:
        user_token = UserToken(user_id=user_id, token=token,expires_at=expires_at)
        db.add(user_token)
        await db.commit()
    return str(token)


async def authenticate_user( db: AsyncSession,username:str, password:str):
    user = await get_user_by_username(db,username)
    if not user:
        return None
    if not security.verify_password(password,user.password):
        return None
    return user

#查询token
# async def get_token_by_user_id(db: AsyncSession, user_id: int):
#     query = select(UserToken).where(UserToken.user_id == user_id)
#     result = await db.execute(query)
#     token_record = result.scalar_one_or_none()
#     return str(token_record.token) if token_record else None



async def get_user_by_token(db: AsyncSession, token:str):
    query = select(UserToken).where(UserToken.token == token)
    result = await db.execute(query)
    token_record = result.scalar_one_or_none()
    if not token_record or token_record.expires_at<datetime.datetime.now():
        return None
    query = select(User).where(User.id == token_record.user_id)
    result = await db.execute(query)
    return result.scalar_one_or_none()

async def updata_user(db: AsyncSession, username: str, user_data: UserRequest):
    query = update(User).where(User.username == username).values(**user_data.model_dump(
        exclude_none=True,
        exclude_unset=True
    ))
    result = await db.execute(query)
    await db.commit()

    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")

    update_user = await get_user_by_username(db, username)

    # 用户资料更新后清理缓存
    from cache.user_cache import invalidate_user_info_cache
    await invalidate_user_info_cache(update_user.id)

    return update_user

async def change_password(db: AsyncSession, user: User, old_password: str, new_password: str):
    if not security.verify_password(old_password, user.password):
        return False
    hashed_new_pwd = security.get_hash_password(new_password)
    user.password = hashed_new_pwd
    db.add(user)
    await db.commit()
    await db.refresh(user)

    # 密码修改后清理用户信息缓存
    from cache.user_cache import invalidate_user_info_cache
    await invalidate_user_info_cache(user.id)

    return True

    
    
