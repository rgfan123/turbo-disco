from email.mime import message


from fastapi import APIRouter, Depends, HTTPException, status, Query
from crud import news, news_cache
from sqlalchemy.ext.asyncio import AsyncSession
from config.db_conf import get_db
#创建APIRouters实例
router = APIRouter(prefix="/api/news", tags=["news"])


# 接口实现流程
# 1. 模块化路由 → API 接口规范文档
# 2. 定义模型类 → 数据库表（数据库设计文档）
# 3. 在 crud 文件夹里面创建文件，封装操作数据库的方法
# 4. 在路由处理函数里面调用 crud 封装好的方法，响应结果



@router.get("/categories")
async def get_categories(skip: int = 0, limit: int = 100,db:AsyncSession=Depends(get_db)):

    categories= await news_cache.get_categories(db,skip, limit)

    return {\
        "code": 200,
        "message": "获取新闻分类列表成功",
        "data":categories
        }

@router.get("/list")
async  def get_news_list(
        category_id: int = Query(...,alias='categoryId'),
        db:AsyncSession=Depends(get_db),
        page: int = 1,
        page_size: int = Query(10, alias="page_size",le=100),
        # db: AsyncSession = Depends(get_db)
):
    offset = ((page-1)*page_size)
    news_list=await news_cache.get_news_list(db,category_id,offset,page_size)
    news_count = await news.get_news_count(db,category_id)
    has_more =(offset+len(news_list))<news_count
    return  {
        "code": 200,
        "message":"获取新闻列表成功",
        "data":{
            "list":news_list,
            "total":news_count,
            "hasMore":has_more
        }
    }

@router.get("/detail")
async def get_news_detail(news_id: int = Query(default=..., alias="id"), db: AsyncSession = Depends(get_db)):
    news_detail = await news_cache.get_news_detail(db, news_id)
    if not news_detail:
        raise HTTPException(status_code=404, detail="新闻不存在")
    views_res = await news.increase_news_views(db, news_id)

    if not views_res:
        raise HTTPException(status_code=404, detail="新闻不存在")
    related_new = await news.get_related_news(db, news_detail.id, news_detail.category_id)
    return {
        "code": 200,
        "message": "success",
        "data": {
            "id": news_detail.id,
            "title": news_detail.title,
            "content": news_detail.content,
            "image": news_detail.image,
            "author": news_detail.author,
            "publishTime": news_detail.publish_time,
            "categoryId": news_detail.category_id,
            "views": news_detail.views,
            "relatedNews": related_new,
        },
    }