from fastapi import APIRouter, Query, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from crud import history as history_crud
from config.db_conf import get_db
from models.users import User
from schemas.history import HistoryAddRequest
from utils.auth import get_current_user
from utils.response import success_response

router = APIRouter(prefix="/api/history", tags=["history"])


@router.post("/add")
async def add_history(
        body: HistoryAddRequest,
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    await history_crud.add_history(db, user.id, body.news_id)
    return success_response(message="添加浏览历史成功")


@router.get("/list")
async def get_history_list(
        page: int = Query(1),
        page_size: int = Query(10),
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    items, total = await history_crud.get_history_list(db, user.id, page, page_size)
    return success_response(
        message="获取浏览历史成功",
        data={"list": items, "total": total, "page": page, "pageSize": page_size}
    )


@router.delete("/delete/{history_id}")
async def delete_history(
        history_id: int,
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    result = await history_crud.delete_history(db, user.id, history_id)
    if not result:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="记录不存在")
    return success_response(message="删除成功")


@router.delete("/clear")
async def clear_history(
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    await history_crud.clear_history(db, user.id)
    return success_response(message="清空浏览历史成功")
