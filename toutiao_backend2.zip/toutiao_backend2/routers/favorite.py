from fastapi import APIRouter, Query, Depends
from starlette import status
from sqlalchemy.ext.asyncio import AsyncSession

from crud import favorite as favorite_crud
from config.db_conf import get_db
from models.users import User
from schemas.favorite import FavoriteCheckResponse, FavoriteAddRequest
from utils.auth import get_current_user
from utils.response import success_response

router = APIRouter(prefix="/api/favorite", tags=["favorite"])


@router.get("/check")
async def check_favorite(
        news_id: int = Query(..., alias="newsId"),
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    is_fav = await favorite_crud.is_news_favorite(db, user.id, news_id)
    return success_response(message="成功", data=FavoriteCheckResponse(isFavorite=is_fav))


@router.post("/add")
async def add_favorite(
        body: FavoriteAddRequest,
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    result = await favorite_crud.add_favorite(db, user.id, body.news_id)
    if not result:
        from fastapi import HTTPException
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="收藏失败或已收藏")
    return success_response(message="收藏成功")


@router.delete("/remove")
async def remove_favorite(
        news_id: int = Query(..., alias="newsId"),
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    result = await favorite_crud.remove_favorite(db, user.id, news_id)
    if not result:
        from fastapi import HTTPException
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="取消收藏失败")
    return success_response(message="取消收藏成功")


@router.get("/list")
async def get_favorite_list(
        page: int = Query(1),
        page_size: int = Query(10),
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    items, total = await favorite_crud.get_favorite_list(db, user.id, page, page_size)
    return success_response(
        message="获取收藏列表成功",
        data={"list": items, "total": total, "page": page, "pageSize": page_size}
    )


@router.delete("/clear")
async def clear_favorites(
        user: User = Depends(get_current_user),
        db: AsyncSession = Depends(get_db)
):
    await favorite_crud.clear_favorites(db, user.id)
    return success_response(message="清空收藏成功")
