from fastapi import APIRouter, HTTPException
from fastapi.params import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from starlette import status

from config.db_conf import get_db
from schemas.users import UserRequest, UserAuthResponse, UserInfoResponse, UserUpdateRequest, UserChangePasswordRequest
from crud import users
from cache.user_cache import get_cache_user_info, set_cache_user_info
from utils.response import success_response
from utils.auth import get_current_user
from models.users import User


router = APIRouter(prefix="/api/user", tags=["users"])

@router.post("/register")
async def register(user_data: UserRequest,db:AsyncSession=Depends(get_db)):

    exitsting_user=await users.get_user_by_username(db, user_data.username)
    if exitsting_user:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="用户已存在")
    user=await users.create_user(db, user_data)
    token=await users.create_token(db, user.id)

    # return {
    #     "code": 200,
    #     "message": "注册成功",
    #     "data": {
    #         "token": token,
    #         "userInfo": {
    #             "id": user.id,
    #             "username": user.username,
    #             "bio": user.bio,
    #             "avatar": user.avatar
    #         }
    #     }
    # }

    response_data=UserAuthResponse(token=token,user_info=UserInfoResponse.model_validate(user))
    return success_response(message="注册成功",data=response_data)


#这个接口模式不会在登录的时候生成新token，只是查询了一下原本token

# @router.post("/login")
# async def login_user(login_data: UserRequest,db:AsyncSession=Depends(get_db)):
#     #登录逻辑：验证用户存在-->验证密码-->生成token-->登录
#     account = await users.authenticate_user(db, login_data.username, login_data.password)
#     if not account:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="登录密码错误")
#     token = await users.get_token_by_user_id(db, account.id)
#     if not token:
#         raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="未找到token，请重新注册")
#     response_data = UserAuthResponse(token=token, user_info=UserInfoResponse.model_validate(account))
#     return success_response(message="登录成功", data=response_data)

@router.post("/login")
async def login_user(login_data: UserRequest,db:AsyncSession=Depends(get_db)):
    #登录逻辑：验证用户存在-->验证密码-->生成token-->登录
    account = await users.authenticate_user(db, login_data.username, login_data.password)
    if not account:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="登录密码错误")
    # token = await users.get_token_by_user_id(db, account.id)
    token=await users.create_token(db, account.id)
    response_data = UserAuthResponse(token=token, user_info=UserInfoResponse.model_validate(account))
    return success_response(message="登录成功", data=response_data)

@router.get("/info")
async def get_user_info(user: User = Depends(get_current_user)):
    cached = await get_cache_user_info(user.id)
    if cached:
        return success_response(message="获取用户信息成功", data=cached)

    user_info = UserInfoResponse.model_validate(user)
    await set_cache_user_info(user.id, user_info.model_dump(mode="json", by_alias=False))
    return success_response(message="获取用户信息成功", data=user_info)


@router.put("/update")

async def update_user_info(user_data: UserUpdateRequest,user: User = Depends(get_current_user),db:AsyncSession=Depends(get_db)):

    updated_user = await users.updata_user(db, user.username, user_data)
    return success_response(message="更新用户信息成功",data=UserInfoResponse.model_validate(updated_user))


@router.put("/password")
async def updata_password(
        password_data:UserChangePasswordRequest,
        user: User = Depends(get_current_user),
        db:AsyncSession=Depends(get_db)
):
    res_change_pwd=await users.change_password(
        db,
        user,
        password_data.old_password,
        password_data.new_password
    )
    if not res_change_pwd:
        raise HTTPException(
            status_code=status.HTTP_500_UNAUTHORIZED,
            detail="修改失败")
    return success_response(message="修改密码成功")



