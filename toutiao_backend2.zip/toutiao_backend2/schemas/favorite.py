from pydantic import BaseModel, Field


class FavoriteCheckResponse(BaseModel):
    isFavorite: bool


class FavoriteAddRequest(BaseModel):
    news_id: int = Field(..., alias="newsId")
