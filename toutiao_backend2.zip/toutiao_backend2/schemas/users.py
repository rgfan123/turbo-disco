# from dataclasses import Field
from typing import Optional, Annotated

from pydantic import BaseModel, ConfigDict, StringConstraints

from typing import Optional, Annotated
from pydantic import BaseModel, Field, StringConstraints

# from typing_inspection.typing_objects import alias

# class UserInfoBase(BaseModel):
#     nickname: Optional[str] = Field(None, max_length=50, description="昵称")
#     avatar: Optional[str] = Field(None, max_length=255, description="头像URL")
#     gender: Optional[str] = Field(None, max_length=10, description="性别")
#     bio: Optional[str] = Field(None, max_length=500, description="个人简介")

class UserInfoBase(BaseModel):
    # 字符串长度约束放入 StringConstraints，Field 只保留默认值+描述
    nickname: Annotated[Optional[str], StringConstraints(max_length=50)] = Field(None, description="昵称")
    avatar: Annotated[Optional[str], StringConstraints(max_length=255)] = Field(None, description="头像URL")
    gender: Annotated[Optional[str], StringConstraints(max_length=10)] = Field(None, description="性别")
    bio: Annotated[Optional[str], StringConstraints(max_length=500)] = Field(None, description="个人简介")

class UserRequest(BaseModel):
    username: str
    password: str

class UserInfoResponse(UserInfoBase):
    id: int
    username: str

    # 模型类配置
    model_config = ConfigDict(
        from_attributes=True  # 允许从 ORM 对象属性中取值
    )




class UserAuthResponse(BaseModel):
    token: str
    user_info: UserInfoResponse=Field(...,alias="userInfo")

    model_config = ConfigDict(
        populate_by_name=True,
        from_attributes=True
    )

class UserUpdateRequest(BaseModel):
    nickname: Optional[str] = None
    avatar: Optional[str] = None
    gender: Optional[str] = None
    bio: Optional[str] = None
    phone: Optional[str] = None

class UserChangePasswordRequest(BaseModel):
    old_password: str=Field(...,alias="old_password")
    new_password: str=Field(...,alias="new_password")
